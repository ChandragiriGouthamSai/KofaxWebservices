const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const mysql = require('mysql2/promise'); // Use pg if using PostgreSQL

const app = express();

// Enable CORS for external access
app.use(cors());

// Configure multer for file uploads
const upload = multer({
    dest: 'uploads/', // Temporary storage for uploaded files
});

// Database connection pool
const db = mysql.createPool({
    host: "localhost", // Update with your DB host
    user: 'root',      // Update with your DB user
    password: 'Gouthams@1',      // Update with your DB password
    database: 'test', // Update with your database name
});

// Initialize the database table
(async () => {
    try {
        const query = `
            CREATE TABLE IF NOT EXISTS uploaded_files (
                id INT AUTO_INCREMENT PRIMARY KEY,
                filename VARCHAR(255) NOT NULL,
                upload_time DATETIME NOT NULL
            );
        `;
        await db.query(query);
        console.log('Database table initialized.');
    } catch (error) {
        console.error('Error initializing database:', error);
    }
})();

// Endpoint to upload multiple PDFs
app.post('/upload', upload.array('pdfs', 10), async (req, res) => {
    if (!req.files || req.files.length === 0) {
        return res.status(400).send('No files uploaded.');
    }

    try {
        const fileDetails = [];
        const connection = await db.getConnection();

        for (const file of req.files) {
            const fileType = file.mimetype;

            // Ensure all uploaded files are PDFs
            if (fileType !== 'application/pdf') {
                fs.unlinkSync(file.path); // Remove the non-PDF file
                return res.status(400).send('Only PDF files are allowed.');
            }

            // Save file details to the database
            const uploadTime = new Date();
            await connection.query(
                'INSERT INTO uploaded_files (filename, upload_time) VALUES (?, ?)',
                [file.filename, uploadTime]
            );

            fileDetails.push({
                message: 'File uploaded successfully.',
                filename: file.filename,
            });
        }

        connection.release();
        const FileNumber = fileDetails.length; // Total number of files uploaded
        res.send({ fileDetails, FileNumber });
    } catch (error) {
        console.error('Error uploading files:', error);
        res.status(500).send('Error uploading files.');
    }
});

// Endpoint to retrieve the uploaded PDF file
app.get('/get-pdf/:filename', (req, res) => {
    const { filename } = req.params;
    const decodedFilename = decodeURIComponent(filename);
    const filePath = path.join(__dirname, 'uploads', decodedFilename);

    if (!fs.existsSync(filePath)) {
        return res.status(404).send('File not found.');
    }

    res.sendFile(filePath, (err) => {
        if (err) {
            console.error(err);
            res.status(500).send('Error sending file.');
        }
    });
});

// Endpoint to retrieve the recently uploaded PDF files
app.get('/get-recent-pdfs', async (req, res) => {
    try {
        const connection = await db.getConnection();
        const [results] = await connection.query(
            'SELECT filename, upload_time FROM uploaded_files ORDER BY upload_time DESC'
        );

        const fileNumber = parseInt(req.query.FileNumber) || results.length;
        const recentFiles = results.slice(0, fileNumber);

        connection.release();
        res.json(recentFiles);
    } catch (error) {
        console.error('Error retrieving recent files:', error);
        res.status(500).send('Error retrieving files.');
    }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
